/* Automatically generated file, do not edit */
#ifndef _h_common_c
#define _h_common_c
libedit_private el_action_t	ed_end_of_file (EditLine *, wint_t);
libedit_private el_action_t	ed_insert (EditLine *, wint_t);
libedit_private el_action_t	ed_delete_prev_word (EditLine *, wint_t);
libedit_private el_action_t	ed_delete_next_char (EditLine *, wint_t);
libedit_private el_action_t	ed_kill_line (EditLine *, wint_t);
libedit_private el_action_t	ed_move_to_end (EditLine *, wint_t);
libedit_private el_action_t	ed_move_to_beg (EditLine *, wint_t);
libedit_private el_action_t	ed_transpose_chars (EditLine *, wint_t);
libedit_private el_action_t	ed_next_char (EditLine *, wint_t);
libedit_private el_action_t	ed_prev_word (EditLine *, wint_t);
libedit_private el_action_t	ed_prev_char (EditLine *, wint_t);
libedit_private el_action_t	ed_quoted_insert (EditLine *, wint_t);
libedit_private el_action_t	ed_digit (EditLine *, wint_t);
libedit_private el_action_t	ed_argument_digit (EditLine *, wint_t);
libedit_private el_action_t	ed_unassigned (EditLine *, wint_t);
libedit_private el_action_t	ed_ignore (EditLine *, wint_t);
libedit_private el_action_t	ed_newline (EditLine *, wint_t);
libedit_private el_action_t	ed_delete_prev_char (EditLine *, wint_t);
libedit_private el_action_t	ed_clear_screen (EditLine *, wint_t);
libedit_private el_action_t	ed_redisplay (EditLine *, wint_t);
libedit_private el_action_t	ed_start_over (EditLine *, wint_t);
libedit_private el_action_t	ed_sequence_lead_in (EditLine *, wint_t);
libedit_private el_action_t	ed_prev_history (EditLine *, wint_t);
libedit_private el_action_t	ed_next_history (EditLine *, wint_t);
libedit_private el_action_t	ed_search_prev_history (EditLine *, wint_t);
libedit_private el_action_t	ed_search_next_history (EditLine *, wint_t);
libedit_private el_action_t	ed_prev_line (EditLine *, wint_t);
libedit_private el_action_t	ed_next_line (EditLine *, wint_t);
libedit_private el_action_t	ed_command (EditLine *, wint_t);
#endif /* _h_common_c */
